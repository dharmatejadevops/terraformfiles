default['apache2']['package_ubuntu'] = 'apache2'
default['apache2']['package_redhat'] = 'httpd'
